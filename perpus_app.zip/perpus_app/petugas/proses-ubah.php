<?php
if ($_POST) {

    include '../config/Database.php';
    include '../object/Petugas.php';

    $database = new Database ();
    $db = $database->getConnection ();

    $petugas = new Petugas ($db);

    $petugas->Email = $_POST ['Email'];
    $petugas->Password = $_POST ['Password'];
    $petugas->Role = $_POST ['Role'];

    $petugas->update();
}

header("Location: http://localhost/perpus_app/petugas/index.php");
?>